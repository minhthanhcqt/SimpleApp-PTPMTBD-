package com.example.mygallery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.MenuItem;

import com.example.mygallery.Fragment.viewPager;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.tabs.TabLayout;


public class MainActivity extends AppCompatActivity {

    private ViewPager viewpager;
    private BottomNavigationView btnNv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewpager=findViewById(R.id.all);
        btnNv=findViewById(R.id.bottom);
        viewPager adapter=new viewPager(getSupportFragmentManager(), FragmentStatePagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        viewpager.setAdapter(adapter);

        viewpager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                switch (position)
                {
                    case 0: btnNv.getMenu().findItem(R.id.image).setChecked(true);
                        break;
                    case 1:  btnNv.getMenu().findItem(R.id.album).setChecked(true);
                        break;
                    case 2:  btnNv.getMenu().findItem(R.id.story).setChecked(true);
                        break;
                    case 3:  btnNv.getMenu().findItem(R.id.face).setChecked(true);
                        break;
                }

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        btnNv.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.all:
                        viewpager.setCurrentItem(0);
                        break;
                    case R.id.album:
                        viewpager.setCurrentItem(1);
                        break;
                    case R.id.story:
                        viewpager.setCurrentItem(2);
                        break;
                    case R.id.face:
                        viewpager.setCurrentItem(3);
                        break;
                }
                return false;
            }
        });

    }
}